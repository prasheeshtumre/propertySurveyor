 @php use App\Models\SecondaryUnitLevelData; @endphp
 <div class="mainDiiv">
     @if (
         $secondary_level_unit_data->property_cat_id != '6' &&
             ($property->cat_id != '4' && $property->plot_land_type != '13'))
         <div class="">
             @if (count(SecondaryUnitLevelData::getMultipleOptions(
                         $secondary_level_unit_data->unit_id,
                         $secondary_level_unit_data->property_id,
                         '20')) >= '1')
                 <p class="ameneties-heading">Amenities</p>
                 <div class="mainFlex">
                     <div class="amenti-dflex">
                         @forelse(SecondaryUnitLevelData::getMultipleOptions($secondary_level_unit_data->unit_id, $secondary_level_unit_data->property_id,'20') as $amenity)
                             <div class="flex-item">
                                 <div class="itemss-flex">
                                     <div>
                                         <img src="{{ url('public/assets/' . SecondaryUnitLevelData::getOptionValues($amenity->amenity_option_id)->icon_path) }}"
                                             class="img-fluid">
                                     </div>
                                     <div>
                                         <p>{{ SecondaryUnitLevelData::getOptionName($amenity->amenity_option_id) }}
                                         </p>
                                     </div>
                                 </div>
                             </div>
                         @empty
                         @endforelse
                     </div>
                 </div>
             @endif

             @if (count(SecondaryUnitLevelData::getMultipleOptions(
                         $secondary_level_unit_data->unit_id,
                         $secondary_level_unit_data->property_id,
                         '29')) >= '1')
                 <p class="ameneties-heading">Society / Building Features</p>
                 <div class="mainFlex">
                     <div class="amenti-dflex">

                         @forelse(SecondaryUnitLevelData::getMultipleOptions($secondary_level_unit_data->unit_id, $secondary_level_unit_data->property_id,'29') as $amenity)
                             <div class="flex-item">
                                 <div class="itemss-flex">
                                     <div>
                                         <img src="{{ url('public/assets/' . SecondaryUnitLevelData::getOptionValues($amenity->amenity_option_id)->icon_path) }}"
                                             class="img-fluid">
                                     </div>
                                     <div>
                                         <p>{{ SecondaryUnitLevelData::getOptionName($amenity->amenity_option_id) }}
                                         </p>
                                     </div>
                                 </div>
                             </div>
                         @empty
                         @endforelse

                     </div>
                 </div>
             @endif

             @if (count(SecondaryUnitLevelData::getMultipleOptions(
                         $secondary_level_unit_data->unit_id,
                         $secondary_level_unit_data->property_id,
                         '30')) >= '1')
                 <p class="ameneties-heading">Additional Features</p>
                 <div class="mainFlex">
                     <div class="amenti-dflex">

                         @forelse(SecondaryUnitLevelData::getMultipleOptions($secondary_level_unit_data->unit_id, $secondary_level_unit_data->property_id,'30') as $amenity)
                             <div class="flex-item">
                                 <div class="itemss-flex">
                                     <div>
                                         <img src="{{ url('public/assets/' . SecondaryUnitLevelData::getOptionValues($amenity->amenity_option_id)->icon_path) }}"
                                             class="img-fluid">
                                     </div>
                                     <div>
                                         <p>{{ SecondaryUnitLevelData::getOptionName($amenity->amenity_option_id) }}
                                         </p>
                                     </div>
                                 </div>
                             </div>
                         @empty
                         @endforelse
                     </div>
                 </div>
             @endif

             @if (count(SecondaryUnitLevelData::getMultipleOptions(
                         $secondary_level_unit_data->unit_id,
                         $secondary_level_unit_data->property_id,
                         '32')) >= '1')
                 <p class="ameneties-heading">Water Source</p>
                 <div class="mainFlex">
                     <div class="amenti-dflex">
                         @forelse(SecondaryUnitLevelData::getMultipleOptions($secondary_level_unit_data->unit_id, $secondary_level_unit_data->property_id,'32') as $amenity)
                             <div class="flex-item">
                                 <div class="itemss-flex">
                                     <div>
                                         <img src="{{ url('public/assets/' . SecondaryUnitLevelData::getOptionValues($amenity->amenity_option_id)->icon_path) }}"
                                             class="img-fluid">
                                     </div>
                                     <div>
                                         <p>{{ SecondaryUnitLevelData::getOptionName($amenity->amenity_option_id) }}
                                         </p>
                                     </div>
                                 </div>
                             </div>
                         @empty
                         @endforelse
                     </div>
                 </div>
             @endif

             @if (count(SecondaryUnitLevelData::getMultipleOptions(
                         $secondary_level_unit_data->unit_id,
                         $secondary_level_unit_data->property_id,
                         '33')) >= '1')
                 <p class="ameneties-heading">Overlooking</p>
                 <div class="mainFlex">
                     <div class="amenti-dflex">

                         @forelse(SecondaryUnitLevelData::getMultipleOptions($secondary_level_unit_data->unit_id, $secondary_level_unit_data->property_id,'33') as $amenity)
                             <div class="flex-item">
                                 <div class="itemss-flex">
                                     <div>
                                         <img src="{{ url('public/assets/' . SecondaryUnitLevelData::getOptionValues($amenity->amenity_option_id)->icon_path) }}"
                                             class="img-fluid">
                                     </div>
                                     <div>
                                         <p>{{ SecondaryUnitLevelData::getOptionName($amenity->amenity_option_id) }}
                                         </p>
                                     </div>
                                 </div>
                             </div>
                         @empty
                         @endforelse

                     </div>
                 </div>
             @endif

             @if (count(SecondaryUnitLevelData::getMultipleOptions(
                         $secondary_level_unit_data->unit_id,
                         $secondary_level_unit_data->property_id,
                         '31')) >= '1')
                 <p class="ameneties-heading">Other Features</p>
                 <div class="mainFlex">
                     <div class="amenti-dflex">
                         @forelse(SecondaryUnitLevelData::getMultipleOptions($secondary_level_unit_data->unit_id, $secondary_level_unit_data->property_id,'31') as $amenity)
                             <div class="flex-item">
                                 <div class="itemss-flex">
                                     <div>
                                         <img src="{{ url('public/assets/' . SecondaryUnitLevelData::getOptionValues($amenity->amenity_option_id)->icon_path) }}"
                                             class="img-fluid">
                                     </div>
                                     <div>
                                         <p>{{ SecondaryUnitLevelData::getOptionName($amenity->amenity_option_id) }}
                                         </p>
                                     </div>
                                 </div>
                             </div>
                         @empty
                         @endforelse
                     </div>
                 </div>
             @endif

             @if (count(SecondaryUnitLevelData::getMultipleOptions(
                         $secondary_level_unit_data->unit_id,
                         $secondary_level_unit_data->property_id,
                         '34')) >= '1')
                 <p class="ameneties-heading">Power Back up</p>
                 <div class="mainFlex">
                     <div class="amenti-dflex">

                         @forelse(SecondaryUnitLevelData::getMultipleOptions($secondary_level_unit_data->unit_id, $secondary_level_unit_data->property_id,'34') as $amenity)
                             <div class="flex-item">
                                 <div class="itemss-flex">
                                     <div>
                                         <img src="{{ url('public/assets/' . SecondaryUnitLevelData::getOptionValues($amenity->amenity_option_id)->icon_path) }}"
                                             class="img-fluid">
                                     </div>
                                     <div>
                                         <p>{{ SecondaryUnitLevelData::getOptionName($amenity->amenity_option_id) }}
                                         </p>
                                     </div>
                                 </div>
                             </div>
                         @empty
                         @endforelse
                     </div>
                 </div>
             @endif

             @if ($secondary_level_unit_data->floor_type != '')
                 <p class="ameneties-heading">Type of Flooring</p>
                 <div class="amenti-dflex">
                     <div class="flex-item">
                         <div class="itemss-flex">
                             @if (SecondaryUnitLevelData::getFloor($secondary_level_unit_data->floor_type) != '')
                                 <div>
                                     <img src="{{ url('public/assets/' . SecondaryUnitLevelData::getFloor($secondary_level_unit_data->floor_type)->icon_path) }}"
                                         class="img-fluid">
                                 </div>
                                 <div>
                                     <p>{{ SecondaryUnitLevelData::getFloor($secondary_level_unit_data->floor_type)->name ?? 'N/A' }}
                                     </p>
                                 </div>
                             @endif
                         </div>
                     </div>

                 </div>
             @endif

             @if ($secondary_level_unit_data->facing_road_width != '')
                 <p class="ameneties-heading">Width of Facing road</p>
                 <div class="flex-item">
                     <div class="itemss-flex">
                         <div>
                             <img src="{{ url('public/assets/images/Layer_1300Meters.svg') }}" class="img-fluid">
                         </div>
                         <div>
                             <p>{{ $secondary_level_unit_data->facing_road_width }}
                                 {{ SecondaryUnitLevelData::getAreaUnit($secondary_level_unit_data->facing_road_width_unit) }}
                             </p>
                         </div>
                     </div>
                 </div>
             @endif

             @if (count(SecondaryUnitLevelData::getMultipleOptions(
                         $secondary_level_unit_data->unit_id,
                         $secondary_level_unit_data->property_id,
                         '21')) >= '1')
                 <p class="ameneties-heading">Location Advantages</p>
                 <div class="mainFlex">
                     <div class="amenti-dflex">

                         @forelse(SecondaryUnitLevelData::getMultipleOptions($secondary_level_unit_data->unit_id, $secondary_level_unit_data->property_id,'21') as $amenity)
                             <div class="flex-item">
                                 <div class="itemss-flex">
                                     <div>
                                         <img src="{{ url('public/assets/' . SecondaryUnitLevelData::getOptionValues($amenity->amenity_option_id)->icon_path) }}"
                                             class="img-fluid">
                                     </div>
                                     <div>
                                         <p>{{ SecondaryUnitLevelData::getOptionName($amenity->amenity_option_id) }}
                                         </p>
                                     </div>
                                 </div>
                             </div>
                         @empty
                         @endforelse
                     </div>
                 </div>
             @endif
         </div>
     @endif
 </div>
