<div class="col-md-4">
    <p><b>GIS Id : </b> <span class="project-head"> {{ $property->gis_id }}</span></p>
</div>
<div class="col-md-4">
    <p><b>Locality Name : </b> <span class="project-head"> {{ $property->locality_name }}</span></p>
</div>
<div class="col-md-4">
    <p><b>Address : </b> <span class="project-head"> {{ $property->street_details }}</span></p>
</div>
